package cs193a.stanford.edu.animalgame

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import kotlinx.android.synthetic.main.activity_play_game.*

class PlayGameActivity : AppCompatActivity() {
    companion object {
        private const val DATABASE_NAME = "animalgame_small"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_play_game)

    }

    fun yesClick(view: View) {
        // TODO
    }

    fun noClick(view: View) {
        // TODO
    }

    fun submitQuestionClick(view: View) {
        // TODO
    }

    fun dumpDbClick(view: View) {
        // TODO
    }

    fun playAgainClick(view: View) {
        // TODO
    }
}
