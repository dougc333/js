# Challenge #2

## Colors

- clr-neutral-100: #fff;
- clr-neutral-400: #474554;
- clr-primary-200: #bac9e8;
- clr-primary-300: #3c7dff;
- clr-primary-400: #0044cc;
- clr-primary-500: #0c1832;

## Typography

Fonts: IBM Plex Serif, Poppins

Font weights: 400 / 700

Font sizes:

- title: 1.75rem
- body: 1rem