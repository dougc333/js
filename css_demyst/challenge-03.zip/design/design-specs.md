# Challenge #3

## Colors

- neutral-100: #fff;
- neutral-900: #030303;
- primary-400: #FF3369;

## Typography

### Fonts: 

- Baloo 2
  - extra bold
- Inter
  - regular
  - medium

### Font sizes:

#### mobile

- title: 68px
- subtitle: 28px
- description: 24px
- section headings: 34px
- body: 17px
- link: 13px

#### desktop

- title: 68px
- subtitle & section headings: 34px
- description: 24px
- body: 17px
- link: 13px

#### 