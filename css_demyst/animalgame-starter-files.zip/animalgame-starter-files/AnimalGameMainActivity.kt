package cs193a.stanford.edu.animalgame

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class AnimalGameMainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_animal_game_main)
    }

    fun playClick(view: View) {
        val myIntent = Intent(this, PlayGameActivity::class.java)
        startActivity(myIntent)
    }

    fun settingsClick(view: View) {
        val myIntent = Intent(this, SettingsActivity::class.java)
        startActivity(myIntent)
    }
}
