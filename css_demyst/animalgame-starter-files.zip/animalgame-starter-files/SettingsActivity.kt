package cs193a.stanford.edu.animalgame

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
//import com.google.firebase.FirebaseApp
//import com.google.firebase.auth.FirebaseAuth


class SettingsActivity : AppCompatActivity() {
    companion object {
        private const val DATABASE_NAME = "animalgame_small"
        private const val FIREBASE_EMAIL = "cs193a@stanford.edu"
        private const val FIREBASE_PASSWORD = "csroxx"
    }

//    private var mAuth: FirebaseAuth? = null
    private var paused = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
    }

    override fun onPause() {
        super.onPause()
        paused = true
    }

    /**
     * Load database initial contents from .sql file.
     */
    fun loadSqlClick(view: View) {
        Toast.makeText(this, "Populating database $DATABASE_NAME ...", Toast.LENGTH_SHORT).show()
        val db = createDatabase(DATABASE_NAME)
        importDatabaseFromFile(DATABASE_NAME)
    }

    /**
     * Prints the contents of the nodes SQL table.
     * Assumes that said table exists.
     */
    fun printSqlClick(view: View) {
        val db = openDatabase(DATABASE_NAME)
        val cr = db.query("SELECT * FROM nodes")
        while (cr.moveToNext()) {
            val id = cr.getInt(cr.getColumnIndex("nodeid"))
            val type = cr.getString(cr.getColumnIndex("type"))
            val text = cr.getString(cr.getColumnIndex("text"))
            Log.d("Marty", "id=$id, type=$type, text=$text")
        }
        cr.close()
    }

    /**
     * Deletes the entire database.
     * Be careful!
     */
    fun deleteSqlClick(view: View) {
        deleteDatabase(DATABASE_NAME)
        Toast.makeText(this, "Database $DATABASE_NAME deleted.", Toast.LENGTH_SHORT).show()
    }

    fun loadFbClick(view: View) {
        // connect to Firebase
//        FirebaseApp.initializeApp(this)
//        if (mAuth == null) {
//            mAuth = FirebaseAuth.getInstance()
//            mAuth?.signInWithEmailAndPassword(FIREBASE_EMAIL, FIREBASE_PASSWORD)
//        }

        // TODO: load the data

    }
}
