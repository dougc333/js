import React from 'react';
import ReactDOM from 'react-dom';
import DeepLink from './components/link/DeepLink';





ReactDOM.render(
    <DeepLink/>,
  document.getElementById('reactapp'),
);


          